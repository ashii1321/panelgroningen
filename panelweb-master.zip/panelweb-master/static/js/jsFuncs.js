$(document).ready(function () {

	var datumNu = new Date();

	if ($('#id_geboortejaar').val()*1 < datumNu.getFullYear() - 17){
		toggleJongeren(true);
	}else{toggleJongeren(false);}
	

	$('#id_geboortejaar').change(function() {

		var jaar = $('#id_geboortejaar').val() * 1 ;
		var borderYear = datumNu.getFullYear() - 17;
		toggleJongeren(jaar<borderYear);


	});

});

function toggleJongeren(boolVal){

	if (boolVal){
		$('.jongeren').hide();
		$('#id_emailadres_toestemming').prop('required',false);

	}else{
		$('.jongeren').show();
		$('#id_emailadres_toestemming').prop('required',true);
	}

}

$('#navbarToggler').focusout(function(){
	alert(1);
});